package production;

import java.util.ArrayList;

public class RobotScheduler implements Tickable{
	static Robot[] robots;
	public RobotScheduler(){
		robots = new Robot[1];
		robots[0] = new Robot(Floor.CHARGER);
	}
	@Override
	public void tick(int tick) {
		for(Robot r : robots)
			r.tick(tick);
	}
	public static Robot getAvailableRobot() {
		for(Robot r:robots)
			if(((Robot)r).isBusy()==false)
				return (Robot)r;
		return null;
	}
	public static void fetchShelf(Order o){
		Robot r = getAvailableRobot();
		if(r == null || o == null)return;
		Shelf s = ItemControl.findItem(o.getUnfilledItemInfo());
		System.out.println("Target shelf: " + s.getPos());//test
		r.state = State.HeadingToShelf;
		r.end = s.getPos();
		r.shelf = s;
		ArrayList<Directions> route = Floor.getRoute(r.getPOS(), s.getPos());
		r.setRoute(route);
	}
	
//	public static void doTask(Order o){
//		Robot r = getAvailableRobot();
//		r.order = o;
//	}
}

enum State{
	IDLE, HeadingToPicker, HeadingToShelf, ReturningShelf, GoToCharge, Charging
}


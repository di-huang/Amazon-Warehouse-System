package production;

public class Master implements Runnable {
	private int limit = 100;					// default: limit = 100 ticks
	private int unitTime = 1000;				// default: 1 second per tick
	private boolean running = false;
	
	private Belt B;
	private Floor F;
	private ItemControl I;
	private OrderControl O;
	private RobotScheduler R;
	private Visualizer V;

	public Master(Belt b, Floor f, ItemControl i, OrderControl o, RobotScheduler r, Visualizer v) {
		B = b;
		F = f;
		I = i;
		O = o;
		R = r;
		V = v;
	}

	@Override
	public void run() {
		int tick = 0;
		while (running && tick < limit) {
			//System.out.println("tick " + tick);
			tick(tick);
			//System.out.println();
			
			unitTime();
			
			tick++;
		}

	}
	
	public void start() {
		running = true;
		new Thread(this).start();
	}
	
	public void stop(){
		running = false;
	}
	
	public void setLimit(int count){
		limit = count;
	}
	
	public void setUnitTime(int milliseconds){
		unitTime = milliseconds;
	}
	
	private void unitTime(){
		try {
			Thread.sleep(unitTime);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private void tick(int tick){
		O.tick(tick);
		R.tick(tick);
		I.tick(tick);
		B.tick(tick);
		V.tick(tick);
	}
}

interface Tickable {
	
	public void tick(int tick);
	
	public default boolean suspend(int suspendedTicks, int currentTick){
		return Math.abs(currentTick - suspendedTicks) % suspendedTicks == 0;
	}
	
}

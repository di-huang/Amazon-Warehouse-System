package production;

public class Item {
	final ItemInfo itemInfo;
	Shelf holder = null;
	public Item(ItemInfo info){
		itemInfo = info;
	}
	public Shelf getHolder() {return holder;}
	public void setHolder(Shelf holder) {this.holder = holder;}
}

class ItemPlot {
	Item item;
	final ItemInfo itemInfo;
	public ItemPlot(ItemInfo info){
		itemInfo = info;
		item = null;
	}
	Item getItem(){return item;}
	void setItem(Item i){item = i;}
	boolean match(Item item){return itemInfo.equals(item.itemInfo);}
}

class ItemInfo{
	final int ID;
	final String description;
	public ItemInfo(int id, String des){
		ID = id;
		description = des;
	}
	public boolean equals(ItemInfo other){
		return this.ID == other.ID;
	}
	@Override
	public String toString() {
		return "ID: " + ID + "; description: " + description;
	}
	
}

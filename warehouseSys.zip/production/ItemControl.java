package production;

import java.util.HashSet;

public class ItemControl implements Tickable {
	static final HashSet<Item> stock = new HashSet<Item>();
	public ItemControl() {
		Shelf shelf1 = Floor.SHELVES[0];
		Shelf shelf2 = Floor.SHELVES[1];

		initItems(catalog[0], 10, shelf1);
		initItems(catalog[1], 10, shelf1);
		initItems(catalog[2], 10, shelf1);
		initItems(catalog[3], 10, shelf2);
		initItems(catalog[4], 10, shelf2);
		initItems(catalog[5], 10, shelf2);
	}
	private void initItems(ItemInfo info, int quantity, Shelf shelf) {
		for (int i = 0; i < quantity; i++) {
			Item item = new Item(info);
			item.setHolder(shelf);
			stock.add(item);
		}
	}
	public static void addItem(Item item) {
		stock.add(item);
	}
	public static int itemStock(ItemInfo info) {
		int quantity = 0;
		for (Item item : stock)
			if (item.itemInfo.equals(info))
				quantity++;
		return quantity;
	}
	/**
	 * @author Ted Herman, Di Huang
	 */
	public static Shelf findItem(ItemInfo info) {
		for (Item e : stock) {
			if (!e.getHolder().onFloor())
				continue; // ignore moving shelves
			if (e.itemInfo.equals(info))
				return e.getHolder();
		}
		// even though this is going to return null (out of stock)
		// go ahead and put the needed item somewhere, like on another
		// shelf
		Item magic = new Item(info); // just what we need
		// search for a shelf which isn't being transported
		magic.setHolder(Floor.SHELVES[0]);	// for temp solution
		return null;
	}
	/**
	 * @author Ted Herman, Di Huang
	 */
	public static Item removeItem(Item a, Shelf s) {
		for (Item e : stock) {
			if (e.getHolder().onFloor())
				continue; // only remove from carried Shelf
			if (!e.equals(a))
				continue; // look for this item only
			if (!e.getHolder().getPos().equals(s.getPos()))
				continue; // only Shelf s
			stock.remove(e);
			e.setHolder(null); // not on Shelf anymore
			return e;
		}
		return null; // not supposed to happen
	}
	public static boolean itemsAvailable(Order order) {
		for (ItemPlot ip : order.getItemPlots())
			if (itemStock(ip.itemInfo) < order.getNeededQuantity(ip.itemInfo))
				return false;
		return true;
	}

	@Override
	public void tick(int tick) {
		// TODO Auto-generated method stub

	}

	public static final ItemInfo[] catalog = { 
			new ItemInfo(1000, "pen"), 
			new ItemInfo(1001, "paper"),
			new ItemInfo(1002, "book"), 
			new ItemInfo(1003, "fork"), 
			new ItemInfo(1004, "spoon"),
			new ItemInfo(1005, "plate"),
			// ...
	};
}

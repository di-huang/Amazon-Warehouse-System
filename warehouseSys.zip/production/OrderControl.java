package production;

import java.util.LinkedList;

public class OrderControl implements Tickable {

	static final LinkedList<Order> orderQueue = new LinkedList<Order>();
	static Order currO;
	public OrderControl(){
		currO = null;
		// generate orders for testing
		orderQueue.add(new Order("a st", new ItemPlot[]{new ItemPlot(ItemControl.catalog[0])}));	// pen
		orderQueue.add(new Order("a st", new ItemPlot[]{new ItemPlot(ItemControl.catalog[4])}));	// spoon
		orderQueue.add(new Order("a st", new ItemPlot[]{new ItemPlot(ItemControl.catalog[1])}));	// paper
		// ...
	}
	
	public static void addOrder(Order orderToBeAdded) {
		orderQueue.add(orderToBeAdded);
	}
	
	@Override
	public void tick(int tick) {
		if(tick==0){return;}
		if(orderQueue.isEmpty()) {
			System.out.println("There is no order.");
			return;
		}
		if(currO == null){
			currO = orderQueue.poll();
			System.out.println("Order-Order-Order " + currO.getItemPlots()[0].itemInfo);
			if(!ItemControl.itemsAvailable(currO)){
				System.out.println("There is no plenty stock for this order right now.");
				orderQueue.add(currO);
				return;
			}
		}
		if(currO.isAllFilled()){
			System.out.println("currO is null now !!!!!!!!!!!!!");
			currO = null;
		}else{
			RobotScheduler.fetchShelf(currO);
		}
	}
}


package production;

import java.util.ArrayList;

public class Robot implements Tickable{
	Point position;
	ArrayList<Directions> route;
	State state;
	Shelf shelf;
	
	public Robot(Point p) {
		position = p;
		route = null;
		state = State.IDLE;
		shelf = null;
	}
	public boolean isBusy() {
		if(state == State.IDLE) return false;
		return true;
	}
	
	int index = 0;
	Point end;
	@Override
	public void tick(int tick) {
		switch(state){
			case IDLE: 
				break;
			case HeadingToPicker:
				System.out.println(OrderControl.currO.getItemPlots()[0].itemInfo);
				if(position.equals(end)){
					System.out.println("Picker is pickng items");
					if(suspend(2,tick)){
						Belt.doPicker(OrderControl.currO);
						Belt.init = true;
						state = State.ReturningShelf;
						Point p = shelf.home;
						route = Floor.getRoute(position, p);
						end = p;
						index = 0;
						OrderControl.currO.allFilled = true;
					}
				}
				break;
			case HeadingToShelf:
				if(position.equals(end)){
					System.out.println("Robot is picking up the shelf...");
					if(suspend(2,tick)){
						shelf.pickup();
						state = State.HeadingToPicker;
						Point p = new Point(2,5);
						route = Floor.getRoute(position, p);
						end = p;
						index = 0;
					}
				}
				break;
			case ReturningShelf:
				if(position.equals(end)){
					state = State.GoToCharge;
					Point p = Floor.CHARGER;
					route = Floor.getRoute(position, p);
					end = p;
					index = 0;
					shelf.putdown();
				}
				break;
			case GoToCharge:
				if(position.equals(end)){
					state = State.IDLE;
					if(OrderControl.orderQueue.isEmpty())return;
					RobotScheduler.fetchShelf(OrderControl.currO);
					index = 0;
				}
				break;
			case Charging:
				
		}
		
		if(route != null && index < route.size()){
			position = nextpoint(position, route.get(index));
			index ++;
		}
		if(shelf != null && !shelf.onFloor()){
			shelf.setPos(position);
		}
		
//		if(order != null){
//			Shelf s = ItemControl.findItem(order.getUnfilledItemInfo());
//			route = Floor.getRoute(Floor.CHARGER, s.getPos());
//			order = null;
//		}
		
	}

	public Point nextpoint(Point pos,Directions d) {
		if(d==Directions.DOWN) {
			return new Point(pos.getX(), pos.getY()+1);
		}
		if(d==Directions.UP) {
			return new Point(pos.getX(), pos.getY()-1);
		}
		if(d==Directions.LEFT) {
			return new Point(pos.getX()-1, pos.getY());
		}
		if(d==Directions.RIGHT) {
			return new Point(pos.getX()+1, pos.getY());
		}
		return null;
	}
	public Point getPOS() {
		return position;
	}
	public void setRoute(ArrayList<Directions> r){
		route = r;
	}

}

package production;

public class Order {
	public final String address;
	private ItemPlot[] itemPlots;
	boolean allFilled;
	public Order(String address, ItemPlot[] itemPlots) {
		this.address = address;
		this.itemPlots = itemPlots;
		allFilled = false;
	}
	public ItemPlot[] getItemPlots() {
		return itemPlots;
	}
	public void setItemPlots(ItemPlot[] itemPlots) {
		this.itemPlots = itemPlots;
	}
	public ItemInfo getUnfilledItemInfo(){
		for(ItemPlot i : itemPlots)
			if(i.getItem() == null)
				return i.itemInfo;
		allFilled = true;
		return null;
	}
	public boolean isAllFilled(){
		return allFilled;
	}
	public int getNeededQuantity(ItemInfo info){
		int quantity = 0;
		for(ItemPlot i : itemPlots)
			if(i.itemInfo.equals(info))
				quantity++;
		return quantity;
	}
}


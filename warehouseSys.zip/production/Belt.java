package production;

import java.awt.Color;
import java.util.LinkedList;

public class Belt implements Tickable{
	
	private static Point beltStart1;
	private Point beltStart2;
	private Point beltEnd1;
	private Point beltEnd2;
	
	private static LinkedList<Bin> belt1 = new LinkedList<Bin>();
	private static LinkedList<Parcel> belt2 = new LinkedList<Parcel>();
	
	public Belt() {
		Point p0 = new Point(0,5); // beltStart1 beside picker
		Point p1 = new Point(0,4);
		Point p2 = new Point(0,3);
		Point p3 = new Point(0,2); // beltEnd1 beside packer
		
		Point p4 = new Point(0,2); // beltStart2 beside packer
		Point p5 = new Point(0,1); 
		Point p6 = new Point(0,0); // beltEnd2 to shipping dock
		
		p0.setNext(p1); 
		p1.setNext(p2);
		p2.setNext(p3);
		p3.setNext(null); 
		
		p4.setNext(p5);
		p5.setNext(p6);
		p6.setNext(null);
		
		beltStart1 = p0;
		beltStart2 = p4;
		beltEnd1 = p3;
		beltEnd2 = p6;
	}
	
	public static LinkedList<Bin> getBelt1() {
		return belt1;
	}

	public static LinkedList<Parcel> getBelt2() {
		return belt2;
	}
	
	public static void doPicker(Order order){
		belt1.add(new Bin(order, beltStart1));
	}
	
	private Parcel doPacker(Bin bin) {
		return new Parcel(bin.order, beltStart2);
	}

	private boolean packFinished = false;
	private Parcel packed;

	static boolean init = false;
	@Override
	public void tick(int tick) {
		if(init == true){
			init = false;
			return;
		}
		for(Parcel pa : belt2){
			Point p = pa.getPoint();
			if(p == beltEnd2){
				belt2.remove();
			}
			pa.setPoint(p.getNext());
		}
		
		if(packFinished){
			belt2.add(packed);
			packFinished = false;
		}
		
		for(Bin b : belt1){
			Point p = b.getPoint();
			if(p == beltEnd1){
				packed = doPacker(belt1.remove());
				packFinished = true;
				break;
			}
			b.setPoint(p.getNext());
		}
	}
}

class Parcel {
	public final Order order;
	private Point point;
	
	public final int width = 10;
	public final Color color = Color.PINK;
	
	public Parcel(Order order, Point point){
		this.order = order;
		this.point = point;
	}

	public Point getPoint() {
		return point;
	}

	public void setPoint(Point point) {
		this.point = point;
	}
}

class Bin{
    public final Order order;
	private Point point;
	
	public final int width = 10;
	public final Color color = Color.ORANGE;

	public Bin(Order order, Point point){
		this.order = order;
		this.point = point;
	}
	
	public Point getPoint() {
		return point;
	}

	public void setPoint(Point point) {
		this.point = point;
	}
}
